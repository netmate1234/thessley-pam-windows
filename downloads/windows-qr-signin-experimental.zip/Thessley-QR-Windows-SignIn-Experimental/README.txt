EXPERIMENTAL: Thessley QR Windows sign-in credential provider

This replaces part of the Windows sign-in experience and is not a routine desktop app. Read
docs/WINDOWS-LOGON-PROTOTYPE.md and the included rollback instructions first. It can be staged over SSH,
but first-time QR setup must be completed at the Windows sign-in screen. Keep PIN/password sign-in available;
do not cancel rollback until a real QR sign-in succeeds. No ADB or USB debugging is needed.
