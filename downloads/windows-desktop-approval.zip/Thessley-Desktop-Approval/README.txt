Thessley Desktop Approval helper

Run ThessleySignInTest.exe as the Windows account being enrolled or tested. The Thessley service must
already be installed and running on this computer, and an enrolled phone must be available. This app does
not change Windows sign-in or login policy.
