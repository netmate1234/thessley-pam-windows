"""The approval service. Runs as SYSTEM (a scheduled task started at boot) and is the only part that reads the list of
approvers and writes passes, so a logged-in user cannot add themselves as an approver or forge a pass.

The gate that sshd starts (gate.py) and the enrol command (cli.py) run as the logged-in user; they connect here. One line of
JSON each way over 127.0.0.1 (more lines follow while the request runs):

    client -> service   {"op": "approve", "user": "alice", "rhost": "192.168.1.50"}
                        {"op": "enroll",  "user": "alice"}
    service -> client   {"say": "text line"}                          show this
                        {"ask": "prompt", "timeout": 90}              the client answers {"answer": "yes"}
                        {"done": true, "ok": true|false}              the end

`enroll` is for a user adding an approver for THEIR OWN account without being an administrator. The service does not trust the
user name in the request: it asks Windows which account owns the connection (peer.py) and refuses anything else. Then:

  * an account with no approver at all may enrol its first one (switch: `thessley-pam-win self-enroll on|off`). A gated account
    with no approver cannot get a shell over ssh, so this means a session on the computer itself;
  * an account that has approvers, but none usable (all disabled, e.g. a lost phone), needs an administrator;
  * otherwise a fresh approval from an enrolled approver is needed first. A pass never counts, and none is created.
"""

import ipaddress
import json
import os
import select
import socket
import socketserver
import threading
import time

from . import approve, enroll, grants, machine, peer, qr, store, web
from .listener import SharedListener

HOST, PORT = "127.0.0.1", 47800
MAX_REQUEST = 2048
MAX_ACTIVE = 8          # approvals waiting at once
_log_lock = threading.Lock()


def log_path() -> str:
    return os.path.join(store.BASE, "service.log")


def log(msg: str, warn: bool = False) -> None:
    try:
        path = log_path()
        with _log_lock:
            settings = grants.web_settings()
            log_limit = settings["log_max_bytes"]
            rotations = settings["log_rotations"]
            for index in range(rotations + 1, 21):
                try:
                    os.remove(f"{path}.{index}")
                except FileNotFoundError:
                    pass
            if os.path.exists(path) and os.path.getsize(path) >= log_limit:
                try:
                    os.remove(f"{path}.{rotations}")
                except FileNotFoundError:
                    pass
                for index in range(rotations - 1, 0, -1):
                    source, target = f"{path}.{index}", f"{path}.{index + 1}"
                    if os.path.exists(source):
                        os.replace(source, target)
                os.replace(path, path + ".1")
            with open(path, "a", encoding="utf-8") as f:
                f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {'WARN' if warn else 'INFO'} {msg}\n")
    except OSError:
        pass


def valid_rhost(rhost) -> bool:
    if rhost == grants.LOCAL:
        return True
    try:
        ipaddress.ip_address(rhost)
        return True
    except (ValueError, TypeError):
        return False


class Handler(socketserver.StreamRequestHandler):
    timeout = 10

    def _send(self, obj: dict) -> bool:
        try:
            self.wfile.write((json.dumps(obj) + "\n").encode("utf-8"))
            self.wfile.flush()
            return True
        except OSError:
            return False

    def handle(self):
        try:
            req = json.loads(self.rfile.readline(MAX_REQUEST + 1))
            assert isinstance(req, dict) and req.get("op") in (
                "approve", "enroll", "admin-enroll", "web-approve", "web-enroll", "windows-logon", "windows-logon-test")
            user = req["user"]
            assert isinstance(user, str)
            rhost = req.get("rhost") or grants.LOCAL
            assert req["op"] in ("enroll", "windows-logon") or valid_rhost(rhost)
        except Exception:
            self._send({"done": True, "ok": False, "error": "bad request"})
            return
        slots: threading.BoundedSemaphore = self.server.slots
        if not slots.acquire(blocking=False):
            self._send({"say": "Thessley Passkey: too many requests are waiting. Refusing."})
            self._send({"done": True, "ok": False})
            return
        cancel = threading.Event()
        try:
            if req["op"] == "approve":
                ok = self._approve(user, rhost, cancel)
            elif req["op"] == "web-approve":
                ok = self._web_approve(user, rhost, req.get("service", "web"), cancel)
            elif req["op"] == "web-enroll":
                ok = self._web_enroll(user, cancel)
            elif req["op"] == "admin-enroll":
                ok = self._admin_enroll(user, cancel)
            elif req["op"] == "windows-logon":
                ok = self._windows_logon(user, cancel)
            elif req["op"] == "windows-logon-test":
                ok = self._windows_logon_test(user, cancel)
            else:
                ok = self._enroll(user, cancel)
        except Exception as e:  # strict: any unexpected failure refuses
            log(f"error for {user!r}: {e!r}", True)
            self._send({"say": "Thessley Passkey: internal error. Refusing."})
            ok = False
        finally:
            slots.release()
        self._send({"done": True, "ok": bool(ok)})

    def _say(self, cancel: threading.Event):
        def say(line: str) -> None:
            if not self._send({"say": line}):
                cancel.set()
        return say

    def _approve(self, user: str, rhost: str, cancel: threading.Event) -> bool:
        self.connection.settimeout(None)

        try:
            normalized = store.normalize_user(user)
            if not store.devices(normalized) and grants.ssh_fallback_unenrolled():
                self._send({"say": "No phone is enrolled for this account; continuing with its configured OpenSSH authentication."})
                log(f"{normalized} used the configured OpenSSH factor because no phone is enrolled", False)
                return True
        except (OSError, ValueError):
            pass

        def watch():  # the client hangs up (ssh session dropped): stop waiting
            try:
                while self.connection.recv(1):
                    pass
            except OSError:
                pass
            cancel.set()

        threading.Thread(target=watch, daemon=True).start()
        return approve.run(user, rhost, "ssh", self._say(cancel), log, cancel=cancel)

    def _web_approve(self, user: str, rhost: str, service: str, cancel: threading.Event) -> bool:
        """Serve web approvals from the daemon so all phones use its one shared HTTPS listener."""
        if not peer.client_is_system(self.client_address, self.server.server_address[1]):
            log(f"web approval refused for {user!r}: caller is not SYSTEM", True)
            return False
        if service not in ("web", "web-change", "add-device") or not valid_rhost(rhost):
            return False
        self.connection.settimeout(None)

        def watch():
            try:
                while self.connection.recv(1):
                    pass
            except OSError:
                pass
            cancel.set()

        threading.Thread(target=watch, daemon=True).start()
        return approve.run(user, rhost, service, self._say(cancel), log, cancel=cancel,
                           use_pass=False, grant_pass=False, wait=web.WEB_WAIT)

    def _web_enroll(self, user: str, cancel: threading.Event) -> bool:
        """Run admin-web enrollment inside the listener-owning service, on the shared single port."""
        if not peer.client_is_system(self.client_address, self.server.server_address[1]):
            log(f"web enrollment refused for {user!r}: caller is not SYSTEM", True)
            return False
        return self._run_enrollment(user, cancel)

    def _admin_enroll(self, user: str, cancel: threading.Event) -> bool:
        """Route the administrator CLI through the same shared listener rather than opening a second port."""
        caller = peer.client_user(self.client_address, self.server.server_address[1])
        if (caller is None or not web.is_admin(caller)
                or not peer.client_is_elevated(self.client_address, self.server.server_address[1])):
            log(f"administrator enrollment refused for {user!r}: caller was {caller!r}", True)
            self._send({"say": "Thessley Passkey: administrator rights are required to add a device for another account."})
            return False
        return self._run_enrollment(user, cancel)

    def _run_enrollment(self, user: str, cancel: threading.Event) -> bool:
        """Run enrollment in the listener-owning daemon; parallel enrollments share its port."""
        try:
            user = store.normalize_user(user)
        except ValueError:
            self._send({"say": "Thessley Passkey: this account name is not supported. Refusing."})
            return False

        stop_watching = self._watch(cancel)
        with self.server.enrolling_lock:
            if user in self.server.enrolling:
                self._send({"say": "Thessley Passkey: an enrolment for this account is already running. Refusing."})
                return False
            self.server.enrolling.add(user)
        try:
            # The SYSTEM web process has already enforced the signed-in session, admin scope, and (for
            # existing accounts) the required step-up approval. Do not ask for that same approval twice.
            self.connection.settimeout(None)

            def enroll_say(line: str) -> None:
                self._say(cancel)(line)

            device = enroll.run(user, enroll_say, self._ask_yes(cancel, stop_watching), cancel=cancel,
                                wait=web.WEB_ENROLL_WAIT, confirm_wait=web.WEB_CONFIRM_WAIT, show_link=True)
            log(f"web page: {'enrolled ' + repr(device['label']) + ' ' + device['credential_id'] if device else 'enrolment not completed'} "
                f"for {user}", device is None)
            return device is not None
        finally:
            stop_watching.set()
            with self.server.enrolling_lock:
                self.server.enrolling.discard(user)

    def _windows_logon(self, user: str, cancel: threading.Event) -> bool:
        """A one-time phone approval for the Windows unlock tile, called by LogonUI as SYSTEM.

        Do not accept this operation from ordinary local processes, and never consume or create an SSH grace pass.
        The Windows authentication package still validates the user's password after the phone approves.
        """
        caller = peer.client_user(self.client_address, self.server.server_address[1])
        if not peer.client_is_system(self.client_address, self.server.server_address[1]):
            self._send({"say": "Thessley Passkey: Windows unlock approval is only available to the lock screen."})
            log(f"Windows unlock approval refused for {user!r}: caller was {caller!r}", True)
            return False

        self.connection.settimeout(None)

        def watch():
            try:
                while self.connection.recv(1):
                    pass
            except OSError:
                pass
            cancel.set()

        threading.Thread(target=watch, daemon=True).start()

        def say(line: str) -> None:
            if line.startswith("Link: "):
                link = line[6:]
                if not self._send({"say": "Scan this QR code with Thessley Passkey to unlock."}):
                    cancel.set()
                    return
                rows = qr.bitmap_rows(link, border=2)
                if not rows or not self._send({"qr_matrix": "/".join(rows)}):
                    cancel.set()
                return
            if any(char in line for char in "▄▀█"):
                return  # native UI receives the same QR as a matrix above
            if not self._send({"say": line}):
                cancel.set()

        return approve.run(
            user, grants.LOCAL, "windows-logon", say, log, cancel=cancel,
            use_pass=False, grant_pass=False, request_type="login",
        )

    def _windows_logon_test(self, user: str, cancel: threading.Event) -> bool:
        """Desktop-only prototype request. Restrict it to the connecting user's own account."""
        caller = peer.client_user(self.client_address, self.server.server_address[1])
        try:
            same_user = caller is not None and store.normalize_user(caller) == store.normalize_user(user)
        except ValueError:
            same_user = False
        if not same_user:
            self._send({"say": "Thessley test: request refused because the app must run as the account being tested."})
            log(f"Windows sign-in test refused for {user!r}: caller was {caller!r}", True)
            return False

        self.connection.settimeout(None)

        def watch():
            try:
                while self.connection.recv(1):
                    pass
            except OSError:
                pass
            cancel.set()

        threading.Thread(target=watch, daemon=True).start()

        def say(line: str) -> None:
            if line.startswith("Link: "):
                if not self._send({"say": "Scan this QR code with Thessley Passkey."}):
                    cancel.set()
                    return
                rows = qr.bitmap_rows(line[6:], border=2)
                if not rows or not self._send({"qr_matrix": "/".join(rows)}):
                    cancel.set()
                return
            if any(char in line for char in "▄▀█"):
                return
            if not self._send({"say": line}):
                cancel.set()

        return approve.run(
            user, grants.LOCAL, "windows-logon", say, log, cancel=cancel,
            use_pass=False, grant_pass=False, request_type="login",
        )

    # -- a user adding an approver for their own account ---------------------------------------------------------------

    def _watch(self, cancel: threading.Event):
        """Cancel when the client hangs up (the terminal was closed). Returns an event that stops the watching."""
        stop = threading.Event()

        def run():
            while not stop.is_set() and not cancel.is_set():
                try:
                    ready, _, _ = select.select([self.connection], [], [], 0.5)
                    if ready:
                        if self.connection.recv(1, socket.MSG_PEEK) == b"":
                            cancel.set()
                            return
                        time.sleep(0.2)  # data is waiting: the client has answered; leave it for the reader
                except OSError:
                    cancel.set()
                    return
        threading.Thread(target=run, daemon=True).start()
        return stop

    def _ask_yes(self, cancel: threading.Event, stop_watching: threading.Event):
        def ask(prompt: str, timeout: int) -> bool:
            stop_watching.set()  # from here the connection is read for the answer
            if not self._send({"ask": prompt, "timeout": timeout}):
                cancel.set()
                return False
            self.connection.settimeout(timeout + 5)
            try:
                reply = json.loads(self.rfile.readline(MAX_REQUEST + 1))
                return str(reply.get("answer", "")).strip().lower() in ("y", "yes")
            except (OSError, ValueError, AttributeError):
                return False
        return ask

    def _enroll(self, user: str, cancel: threading.Event) -> bool:
        say = self._say(cancel)
        try:
            user = store.normalize_user(user)
        except ValueError:
            say("Thessley Passkey: this account name is not supported. Refusing.")
            return False
        caller = peer.client_user(self.client_address, self.server.server_address[1])
        try:
            same = caller is not None and store.normalize_user(caller) == user
        except ValueError:
            same = False
        if not same:
            say("Thessley Passkey: you can only add an approver for your own account. An administrator can add one for others.")
            log(f"enrol for {user} refused: asked by {caller!r}", True)
            return False

        stop_watching = self._watch(cancel)
        with self.server.enrolling_lock:
            if user in self.server.enrolling:
                say("Thessley Passkey: an enrolment for this account is already running. Refusing.")
                return False
            self.server.enrolling.add(user)
        try:
            if not self._allowed_to_enroll(user, say, cancel):
                return False
            self.connection.settimeout(None)
            def enroll_say(line: str) -> None:
                if line.startswith("Link: "):
                    rows = qr.bitmap_rows(line[6:], border=2)
                    if rows:
                        self._send({"qr_matrix": "/".join(rows)})
                say(line)

            device = enroll.run(user, enroll_say, self._ask_yes(cancel, stop_watching), cancel=cancel, show_link=True)
            log(f"{'enrolled ' + repr(device['label']) + ' ' + device['credential_id'] if device else 'enrolment not completed'} "
                f"for {user} (by themselves)", device is None)
            return device is not None
        finally:
            stop_watching.set()
            with self.server.enrolling_lock:
                self.server.enrolling.discard(user)

    def _allowed_to_enroll(self, user: str, say, cancel: threading.Event) -> bool:
        everything = store.devices(user)          # including disabled ones
        if not everything:
            if grants.self_enroll_first():
                log(f"{user} enrols their first approver", False)
                return True
            say("Thessley Passkey: adding the first approver needs an administrator on this computer.")
            log(f"first enrolment for {user} refused: self-enrolment is off", True)
            return False
        if not store.active_devices(user):
            say("Thessley Passkey: every approver of this account is switched off. An administrator has to add a new one.")
            log(f"enrolment for {user} refused: all approvers disabled", True)
            return False
        say("This account already has an approver. Approve adding a new device on it first.")
        if approve.run(user, grants.LOCAL, "add-device", say, log, cancel=cancel, use_pass=False, grant_pass=False):
            return True
        log(f"enrolment for {user} refused: not approved by an existing approver", True)
        return False


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, addr=(HOST, PORT)):
        super().__init__(addr, Handler)
        self.slots = threading.BoundedSemaphore(MAX_ACTIVE)
        self.enrolling: set[str] = set()
        self.enrolling_lock = threading.Lock()


def main() -> int:
    store.ensure_dirs()
    grants.clear_all()  # a restart ends every pass
    cert_dir = os.path.join(store.BASE, "approvals")
    cert_path, key_path = os.path.join(cert_dir, "cert.pem"), os.path.join(cert_dir, "key.pem")
    shared = None
    last_network_log = 0.0
    while shared is None:
        try:
            ip = machine.lan_ip()
            parsed_ip = ipaddress.ip_address(ip)
            if parsed_ip.is_loopback or parsed_ip.is_link_local or parsed_ip.is_unspecified:
                raise OSError("no usable LAN address yet")
            fingerprint = web.ensure_cert(cert_path, key_path, [ip])
            candidate = SharedListener(ip, cert_path, key_path, fingerprint)
            candidate.start()
            shared = candidate
        except (OSError, ValueError) as e:
            now = time.monotonic()
            if now - last_network_log >= 30:
                log(f"waiting for a usable network address before starting the approval listener: {e}", True)
                last_network_log = now
            time.sleep(1)
    approve.set_shared_listener(shared)
    server = Server()
    log(f"service started on {HOST}:{server.server_address[1]} and HTTPS approval listener {ip}:47810")
    try:
        server.serve_forever()
    finally:
        server.server_close()
        shared.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
